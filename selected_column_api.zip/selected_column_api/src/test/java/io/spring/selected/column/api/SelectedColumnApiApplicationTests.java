package io.spring.selected.column.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SelectedColumnApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
