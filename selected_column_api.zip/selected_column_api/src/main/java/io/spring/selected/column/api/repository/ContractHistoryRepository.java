package io.spring.selected.column.api.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import io.spring.selected.column.api.entity.ContractHistory;

public interface ContractHistoryRepository extends JpaRepository<ContractHistory, String> {

	@Query(value  = "SELECT contract_id, duration, amount, status FROM contract_history" ,nativeQuery = true)
	List<ContractHistory> findByStatusAndDurationAndContractId(String contractId, Integer duration, Double amount,
			String status);
			                                                                                                   

}
