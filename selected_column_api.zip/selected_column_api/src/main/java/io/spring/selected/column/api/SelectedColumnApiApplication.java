package io.spring.selected.column.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SelectedColumnApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SelectedColumnApiApplication.class, args);
	}

}
