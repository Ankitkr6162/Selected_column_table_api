package io.spring.selected.column.api.dto;

import org.hibernate.annotations.GenericGenerator;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class ContractHistoryDTO {

	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	private String contractId;
	private Integer duration;
	private Double amount;
	private String status;

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ContractHistoryDTO(String contractId, Integer duration, Double amount, String status) {
		super();
		this.contractId = contractId;
		this.duration = duration;
		this.amount = amount;
		this.status = status;
	}

	public ContractHistoryDTO() {
		super();

	}

}
