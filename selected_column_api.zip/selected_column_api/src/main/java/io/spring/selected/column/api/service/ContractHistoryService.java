package io.spring.selected.column.api.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import io.spring.selected.column.api.dto.ContractHistoryDTO;
import io.spring.selected.column.api.entity.ContractHistory;
import io.spring.selected.column.api.repository.ContractHistoryRepository;

@Service
public class ContractHistoryService {

	    @Autowired
	    private ContractHistoryRepository contractHistoryRepository;

	    public List<ContractHistoryDTO> fetchData(String contractId, Integer duration, Double amount, String status) {
	        List<ContractHistory> contractHistoryList = contractHistoryRepository
	            .findByStatusAndDurationAndContractId(contractId, duration, amount, status);
	        // Convert entities to DTOs
	        return contractHistoryList.stream()
	            .map(this::convertToDTO)
	            .collect(Collectors.toList());
	    }

	    private ContractHistoryDTO convertToDTO(ContractHistory contractHistory) {
	        ContractHistoryDTO dto = new ContractHistoryDTO();
	        dto.setContractId(contractHistory.getContractId());
	        dto.setDuration(contractHistory.getDuration());
	        dto.setAmount(contractHistory.getAmount());
	        dto.setStatus(contractHistory.getStatus());
	       
	        return dto;
	    }
	
	
}
