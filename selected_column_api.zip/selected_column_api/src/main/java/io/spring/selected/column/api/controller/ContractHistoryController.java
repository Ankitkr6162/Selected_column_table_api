package io.spring.selected.column.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.spring.selected.column.api.dto.ContractHistoryDTO;
import io.spring.selected.column.api.service.ContractHistoryService;

@RestController
@RequestMapping("/api")
public class ContractHistoryController {
	
	@Autowired
    private ContractHistoryService contractHistoryService;

    @GetMapping("/fetch")
    public ResponseEntity<List<ContractHistoryDTO>> fetchData(
        @RequestParam(required = false , name = "contractId") String contractId ,
        @RequestParam(required = false , name = "duration") Integer duration ,
        @RequestParam(required = false , name = "amount") Double amount ,
        @RequestParam(required = false , name = "status") String status ) {
		List<ContractHistoryDTO> contractHistoryDTOList = contractHistoryService.fetchData(contractId, duration, amount, status);
        return new ResponseEntity<>(contractHistoryDTOList, HttpStatus.OK);
    }

}
